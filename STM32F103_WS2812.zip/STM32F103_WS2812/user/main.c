#include "sys.h"
#include "ws2812.h"
#include "usart.h"
#include "spi.h"

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIOC->ODR |= GPIO_Pin_13;
}

int main()
{
    int i;
    
    SystemInit();
    delay_init();
    uart_init(115200);
    WS2812_Init();
    LED_Init();
    
    if(GPIOB->IDR & GPIO_Pin_11)
    {
        i = 108;
        while(i --)
        {
            WS2812_Send(SPI1, 0x7F7F7F);
        }
        
        i = 108;
        while(i --)
        {
            WS2812_Send(SPI2, 0x7F7F7F);
        }
    }
    else
    {
        WS2812_Send(SPI1, 0x7F7F7F);
        WS2812_Send(SPI1, 0x7F7F7F);
        WS2812_Send(SPI2, 0x7F7F7F);
        WS2812_Send(SPI2, 0x7F7F7F);
    }
    
    while(1)
    {
        GPIOC->ODR |= GPIO_Pin_13;
        delay_ms(300);
        GPIOC->ODR &= ~GPIO_Pin_13;
        delay_ms(300);
    }
}







