#include "sys.h"


//系统心跳
volatile uint32_t SysTime = 0;
unsigned int fac_us;
unsigned int fac_ms;

void delay_init(void)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
    //1ms 中断一次
    SysTick_Config(SystemCoreClock / 1000);
    
    fac_ms = SysTick->LOAD;//获取基数
    if((fac_ms) > 1000)
        fac_us = (fac_ms + 1) / 1000;
    else
        fac_us = 1;
    SysTime = 0;
}

//延时一微秒
//测试
//extern unsigned int srart_us, first_time;
//extern unsigned int end_us, end_systick;
void delay_us(unsigned int us)
{
    unsigned int first_val = SysTick->VAL;//记录刚进来的时候定时器的值
    unsigned int ms = SysTime;
    
    if(us == 0)
        return;
    
    if(us >= 1000)//超过1ms
    {
        delay_ms(us / 1000);//机智
        ms = SysTime;//更新时间
        us %= 1000;//求余
    }
    
    us *= fac_us;//取滴答定时器延时x us的实际值
    if(us > first_val)
    {
        ms ++;
        while(ms > SysTime);//等待定时器重置
        us -= first_val;
        first_val = fac_ms;//这里fan_ms用SysTick->LOAD更标准
    }
    //到了这里SysTick->Val一定不会比us小
    us = first_val - us;//定时器计数到这，就表示延时完成
    if(us < 5)
        us = 5;//防止卡bug
    //这里us不能等于0，会出事，最好在5以上
    //实测us = 1也不是不行，等待测试结果
    while(SysTick->VAL > us);//等待最后延时

}


//延时一毫秒
void delay_ms(unsigned int ms)
{
    //记录刚进来的时候定时器的值，实测有1us误差，在这里消除
    unsigned int first_val = SysTick->VAL;
    
    if(ms == 0)
        return;
    ms += SysTime;
    //不正常情况（SysTime这个变量总有溢出的一天，虽说是小概率。或者说你并没有开启滴答定时器）
    if(ms < SysTime)
        while(ms < SysTime);//等待SysTime归零
    //下面是正常情况
    //等待延时
    while(ms > SysTime);
    //延时差不多达标，但又没完全达标
    //既然程序能走到这里，SysTick->VAL的值一定等于fac_ms，或者稍微比它小一点
    if(first_val < 5)
        first_val = 5;//防止卡bug
    while(SysTick->VAL > first_val);
}

//字符串转十进制
int Str_to_dec(const char *buf)
{
	int i;
	int neg = 0;//负号标志
	int rec = 0;
	int len = strlen(buf);

	if(buf[0] == '-')
		neg ++;

	//非法输入
	if((len == 0) || ((len - neg) > 10))
		return 0;

	for(i = 0; i < len; i++)
	{
		if(buf[i + neg] >= '0' && buf[i + neg] <= '9')
		{
			rec *= 10;
			rec += buf[i + neg] - '0';
		}
	}
	if(neg)
		return rec * -1;
	return rec;
}

int Str_to_hex(const char *buf)
{
    int i;
    int len = strlen(buf);
    int rec = 0;
    char neg = 0;
    if(buf[0] == '-')
    {
        neg ++;
    }

    for(i = 2; i < len; i++)
    {
        if((buf[i + neg] <= '9') && (buf[i + neg] >= '0'))
        {
            rec *= 16;
            rec += buf[i + neg] - '0';
        }
        else if((buf[i + neg] <= 'F') && (buf[i + neg] >= 'A'))
        {
            rec *= 16;
            rec += buf[i + neg] - 'A' + 10;
        }
        else if((buf[i + neg] <= 'f') && (buf[i + neg] >= 'a'))
        {
            rec *= 16;
            rec += buf[i + neg] - 'a' + 10;
        }
    }
    if(neg)
        return rec * -1;
    return rec;
}



//字符转数字
int str_to_num(const char *buf, unsigned int len)
{
    if((buf[0] == '0') && buf[1] == 'x')
        return Str_to_hex(buf);
    return Str_to_dec(buf);
}

//整形转字符
int Dec_to_str(int num, char *buf, int len)
{
	int i = 0;
	int cnt = 1;
	int tmp;

	if(num == 0)//止步于此
	{
		buf[0] = '0';
		return 0;
	}
    if(num < 0)
	{
		buf[0] = '-';
		num *= -1;
		i++;
	}
	tmp = num;
	while(tmp)
	{
		tmp /= 10;
		cnt *= 10;
	}
	cnt /= 10;
	
	for(; i < len; i++)
	{	
		buf[i] = '0' + (num / cnt);
		num = num % cnt;
		if(cnt > 9)
			cnt /= 10;
		else
			break;
	}
    return 1;
}

int Hex_to_str(int num, char *str, int len)
{
    int i;
    int cnt = 1;
    int tmp = num;
    
    if(len < 3)
        return 0;
    if(num == 0)
    {
        memcpy(str, "0x0", 3);
        return 1;
    }
    memcpy(str, "0x", 2);
    while(tmp > 15)
    {
        cnt *= 16;
        tmp /= 16;
    }
    
    for(i = 2; i < len; i++)
    {
        tmp = num / cnt;
        num %= cnt;
        if(tmp > 9)
            str[i] = 'A' + tmp - 10;
        else
            str[i] = '0' + tmp;
        if(cnt > 15)
            cnt /= 16;
        else
            break;
    }
    
    return 1;
}

int Bin_to_str(unsigned int num, char *str, int len)
{
    char buf[32];
    int i;

    if(len < 3)
        return 0;
    memcpy(str, "0b", 2);
    if(num == 0)
    {
        str[2] = '0';
        return 1;
    }
    
    
    for(i = 0; i < 32; i++)
    {
        if(num & (0x01 << 31 - i))
            buf[i] = '1';
        else
            buf[i] = '0';
    }

    for(i = 0; i < 3; i++)
    {
        if(buf[0] == '0')
            if(buf[1] == '0')
                if(buf[2] == '0')
                    if(buf[3] == '0')
                        memcpy(buf, &buf[4], 32 - 4);
    }
    i = strlen(buf);
    if(i > 32)
        i = 32;
    memcpy(&str[2], buf, i);
    return 1;
}



//数字转字符串
void num_to_str(char char_type, int input_num, char *out_buf, int buf_len)
{
    switch(char_type)
    {
        case 'b'://bin
            Bin_to_str(input_num, out_buf, buf_len);
            break;
        case 'd'://dec
            Dec_to_str(input_num, out_buf, buf_len);
            break;
        case 'h'://hex
            Hex_to_str(input_num, out_buf, buf_len);
            break;
        default://dec
            Dec_to_str(input_num, out_buf, buf_len);
            break;
    }
}




//********************************************************************************  
//THUMB指令不支持汇编内联
//采用如下方法实现执行汇编指令WFI  
__asm void WFI_SET(void)
{
	WFI;		  
}

__asm void INTX_DISABLE(void)
{
	CPSID I;		  
}

__asm void INTX_ENABLE(void)
{
	CPSIE I;		  
}

__asm void MSR_MSP(uint32_t addr) 
{
	MSR MSP, r0 			//set Main Stack value
	BX r14
}

//关CPU所有中断
__asm void CPU_IntDis (void)
{
	CPSID   I
	BX      LR
}

//开CPU所有中断
__asm void CPU_IntEn (void)
{
	CPSIE   I
	BX      LR
}


#define HSE_CLOCK    8
//SYS_CLOCK: 选定的系统时钟频率36~72
//HSE_CLOCK: 外部晶振频率，有时候不一定是8MHz
void Stm32_Clock_Init(unsigned int SYS_CLOCK)
{
	unsigned char temp = 0;
    unsigned char PLL;
	
	//预判一波
	if(SYS_CLOCK >= 8000000)
		PLL = ((SYS_CLOCK / 1000000) / HSE_CLOCK) - 2;
	else
		PLL = (SYS_CLOCK / HSE_CLOCK) - 2;
	if(PLL > 7)
	{
		SystemInit();
		return;
	}
	
    //复位
    RCC->APB1RSTR = 0x00000000;//复位结束
	RCC->APB2RSTR = 0x00000000;
  	RCC->AHBENR = 0x00000014;  //睡眠模式闪存和SRAM时钟使能.其他关闭
  	RCC->APB2ENR = 0x00000000; //外设时钟关闭
  	RCC->APB1ENR = 0x00000000;
	RCC->CR |= 0x00000001;     //使能内部高速时钟HSION
	RCC->CFGR &= 0xF8FF0000;   //复位SW[1:0],HPRE[3:0],PPRE1[2:0],PPRE2[2:0],ADCPRE[1:0],MCO[2:0]
	RCC->CR &= 0xFEF6FFFF;     //复位HSEON,CSSON,PLLON
	RCC->CR &= 0xFFFBFFFF;     //复位HSEBYP
	RCC->CFGR &= 0xFF80FFFF;   //复位PLLSRC, PLLXTPRE, PLLMUL[3:0] and USBPRE
	RCC->CIR = 0x00000000;     //关闭所有中断
    
    //配置向量表
    SCB->VTOR = 0x08000000;//设置NVIC的向量表偏移寄存器
    
    
 	RCC->CR|=0x00010000;  //外部高速时钟使能HSEON
	while(!(RCC->CR>>17));//等待外部时钟就绪
	RCC->CFGR=0X00000400; //APB1=DIV2;APB2=DIV1;AHB=DIV1;
	RCC->CFGR|=PLL<<18;   //设置PLL值 2~16
	RCC->CFGR|=1<<16;	  //PLLSRC ON
	FLASH->ACR|=0x32;	  //FLASH 2个延时周期
	RCC->CR|=0x01000000;  //PLLON
	while(!(RCC->CR>>25));//等待PLL锁定
	RCC->CFGR|=0x00000002;//PLL作为系统时钟
	while(temp!=0x02)     //等待PLL作为系统时钟设置成功
	{   
		temp=RCC->CFGR>>2;
		temp&=0x03;
	}    
}

//使用printf函数会调用到这个函数
//要包含stdio.h
//这里用的串口二，将来使用其他外设在这里更改
//int fputc(int ch, FILE *stream)
//{
//    while((USART2 -> SR & 0x40) == 0);
//    USART2 -> DR = ch;
//    return ch;
//}
/**************** end *******************/





