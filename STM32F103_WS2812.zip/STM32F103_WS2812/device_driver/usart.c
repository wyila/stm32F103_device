#ifndef __WS2812_H
#define __WS2812_H

#include "stm32f10x.h"

void WS2812_Init(void);
void char_to_ws(unsigned char *Byte, unsigned int *WS_Data, unsigned int len);
void WS2812_Send(SPI_TypeDef *SPIx, unsigned int RGB);

void RGB_Test(unsigned char num);

#endif





