#include "spi.h"
#include "ws2812.h"

void WS2812_Init(void)
{
    SPI1_Init();
    SPI2_Init();
}

//字节转WS2812格式
void char_to_ws(unsigned char *Byte, unsigned int *WS_Data, unsigned int len)
{
    unsigned int i, j;
    for(i = 0; i < len; i++)
    {
        WS_Data[i] = 0;
        for(j = 0; j < 8; j++)
        {
            WS_Data[i] <<= 3;
            if((Byte[i] >> (7 - j)) & 1)
                WS_Data[i] |= 0x6;
            else
                WS_Data[i] |= 0x4;
        }
    }
}


//24bit
void WS2812_Send(SPI_TypeDef *SPIx, unsigned int RGB)
{
    unsigned char i, j;
    unsigned char color[3];
    unsigned char WS_DATA[3 * 3 * 8];
    unsigned int tmp;
    unsigned int retry = 0;
    
    RGB &= 0XFFFFFF;
    color[0] = (RGB >> 16) & 0xFF;//R
    color[1] = (RGB >> 8) & 0xFF;//G
    color[2] = RGB & 0xFF;//B
    
    //格式转换
    for(i = 0; i < 3; i++)
    {
        tmp = 0;
        for(j = 0; j < 8; j ++)
        {
            tmp <<= 3;
            if((color[i] >> (7 - j)) & 0x01)
                tmp |= 0x06;
            else
                tmp |= 0x04;
        }
        WS_DATA[i * 3 + 2] = (tmp >> 16) & 0xFF;
        WS_DATA[i * 3 + 1] = (tmp >> 8) & 0xFF;
        WS_DATA[i * 3] = tmp & 0xFF;
    }
    
    for(i = 0; i < 9; i++)
    {
        while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_TXE) == RESET)
        {
            retry ++;
            if(retry > 2000)
                return;
        }
        SPI_I2S_SendData(SPIx, WS_DATA[8 - i]);
    }
        
}



void RGB_Test(unsigned char num)
{
    switch(num)
    {// 00B 00R 00G
        case 0:WS2812_Send(SPI1, 0x0000FF);
            break;
        case 1:WS2812_Send(SPI1, 0x0F0FFF);
            break;
        case 2:WS2812_Send(SPI1, 0x0000FF);
            break;
        case 3:WS2812_Send(SPI1, 0xFF00FF);
            break;
        case 4:WS2812_Send(SPI1, 0xFF0F00);
            break;
        case 5:WS2812_Send(SPI1, 0xFF0F1F);
            break;
        case 6:WS2812_Send(SPI1, 0xFF0000);
            break;
        case 7:WS2812_Send(SPI1, 0xFF0F1F);
            break;
        case 8:WS2812_Send(SPI1, 0xFF0F0F);
            break;
        case 9:WS2812_Send(SPI1, 0xFF3F3F);
            break;
    }
}





