#ifndef __SPI_H
#define __SPI_H


void SPI1_Init(void);
void SPI2_Init(void);




#endif








