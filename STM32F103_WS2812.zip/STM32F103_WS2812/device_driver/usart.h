#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

//定义最大接收字节数 200
#define USART_RX_SIZE   200

extern unsigned int USART_RX_LEN;
extern u8 USART_RX_BUF[USART_RX_SIZE + 1]; //接收缓冲,最大USART_REC_LEN个字节.末字节为换行符 
extern u8 USART_RX_STA;         		//接收状态标记	

void uart_init(u32 bound);
#endif


